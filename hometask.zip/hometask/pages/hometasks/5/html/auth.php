<h3>Сторінка авторизації</h3>

<form method="POST" action="../login.php" >
    <label>
        <input type="text" name="username" placeholder="Username">
    </label>
    <label>
        <input type="password" name="password" placeholder="Password">
    </label>
    <button type="submit" name="submit">Login</button>
</form>